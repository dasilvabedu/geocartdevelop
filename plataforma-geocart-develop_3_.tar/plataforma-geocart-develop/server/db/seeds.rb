load './db/seeds/users.rb'

#################
# SANITY CHECKS #
#################

puts "\n##################   SANITY CHECKS   ##################\n\n"
puts " #{User.count} user(s)."
puts "\n#######################################################\n\n"

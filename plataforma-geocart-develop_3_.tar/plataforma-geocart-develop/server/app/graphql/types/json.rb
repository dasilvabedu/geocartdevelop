class Types::JSON < Types::BaseScalar
  description "A valid JSON"
end

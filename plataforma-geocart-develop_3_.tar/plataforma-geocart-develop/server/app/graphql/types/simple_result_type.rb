class Types::SimpleResultType < Types::BaseObject
  field :ok, Boolean, null: false
end

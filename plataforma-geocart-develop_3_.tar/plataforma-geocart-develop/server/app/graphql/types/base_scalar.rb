class Types::BaseScalar < GraphQL::Schema::Scalar
end

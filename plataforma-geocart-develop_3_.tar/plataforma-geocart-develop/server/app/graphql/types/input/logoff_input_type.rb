class Types::Input::LogoffInputType < Types::BaseInputObject
  argument :input, String, required: false
end

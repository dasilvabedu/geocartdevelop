class ApplicationMailer < ActionMailer::Base
  default from: "Geocart <nao-responda@geocart.com>"
  layout false
end

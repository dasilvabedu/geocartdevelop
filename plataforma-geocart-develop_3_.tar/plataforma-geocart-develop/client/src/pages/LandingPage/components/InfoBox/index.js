export { default } from './InfoBox';

export { default } from './MapCanvas';

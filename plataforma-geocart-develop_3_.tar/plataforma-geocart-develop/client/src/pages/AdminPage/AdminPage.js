import React from 'react'
import { withStyles} from '@material-ui/core'

const styles = _theme => ({})

function AdminPage(props) {
  return (
    <p>Admin Page</p>
  )
}

export default withStyles(styles)(AdminPage)

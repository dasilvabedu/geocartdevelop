export { default } from './BasePage';
